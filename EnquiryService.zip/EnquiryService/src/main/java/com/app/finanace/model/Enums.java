package com.app.finanace.model;

public enum Enums {

	accept,reject;
}
